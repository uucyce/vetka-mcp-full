# VETKA MCP SKILL

## Overview

VETKA MCP Server provides tools for AI agents to interact with the VETKA knowledge system.
Any AI agent (Claude, GPT, Gemini, Grok, Ollama) can connect and use these tools.

**Vision:** "VETKA — workshop for agents, spacesuit for humans"

## Connection

### REST API (Recommended)

```bash
# Check status
curl http://localhost:5001/api/mcp/status

# List tools
curl http://localhost:5001/api/mcp/tools

# Call a tool
curl -X POST http://localhost:5001/api/mcp/call \
  -H "Content-Type: application/json" \
  -d '{"name": "TOOL_NAME", "arguments": {...}}'
```

### WebSocket

```
ws://localhost:5001/mcp
```

Events:
- `connect` - Agent connects
- `list_tools` - Request tool list
- `tool_call` - Call a tool
- `tool_result` - Receive result

---

## Available Tools (11)

### Read-Only (Safe)

| Tool | Description |
|------|-------------|
| `vetka_search` | Search files by name/content |
| `vetka_search_knowledge` | Semantic search with embeddings |
| `vetka_get_tree` | Get folder/file hierarchy |
| `vetka_get_node` | Get file/folder details |
| `vetka_list_files` | List directory contents |
| `vetka_read_file` | Read file content |
| `vetka_git_status` | Get git status |

### Write Operations (Use with Caution)

| Tool | Description |
|------|-------------|
| `vetka_create_branch` | Create folder (dry_run default) |
| `vetka_edit_file` | Edit/create file (dry_run default) |
| `vetka_git_commit` | Git commit (dry_run default) |
| `vetka_run_tests` | Run pytest tests |

---

## Examples

### Search for files

```json
{
  "name": "vetka_search",
  "arguments": {
    "query": "authentication",
    "limit": 5
  }
}
```

### Semantic search

```json
{
  "name": "vetka_search_knowledge",
  "arguments": {
    "query": "how does the layout algorithm work",
    "limit": 10,
    "min_score": 0.5
  }
}
```

### List Python files

```json
{
  "name": "vetka_list_files",
  "arguments": {
    "path": "src",
    "depth": 2,
    "pattern": "*.py"
  }
}
```

### Read a file

```json
{
  "name": "vetka_read_file",
  "arguments": {
    "path": "src/main.py",
    "max_lines": 100
  }
}
```

### Get tree structure

```json
{
  "name": "vetka_get_tree",
  "arguments": {
    "path": "/",
    "depth": 3
  }
}
```

### Get git status

```json
{
  "name": "vetka_git_status",
  "arguments": {}
}
```

### Run tests

```json
{
  "name": "vetka_run_tests",
  "arguments": {
    "test_path": "tests/test_mcp_server.py",
    "verbose": true,
    "timeout": 60
  }
}
```

### Edit file (preview)

```json
{
  "name": "vetka_edit_file",
  "arguments": {
    "path": "README.md",
    "content": "# New content\n\nUpdated readme.",
    "dry_run": true
  }
}
```

### Create commit (preview)

```json
{
  "name": "vetka_git_commit",
  "arguments": {
    "message": "feat: add new feature",
    "files": ["src/new_feature.py"],
    "dry_run": true
  }
}
```

---

## Safety Rules

1. **All write tools default to `dry_run: true`**
   - Preview changes before applying
   - Set `dry_run: false` only after reviewing

2. **Automatic backups**
   - Edit operations create backups in `.vetka_backups/`
   - Backups named: `filename.YYYYMMDD_HHMMSS.bak`

3. **Path traversal blocked**
   - `..` in paths is rejected
   - All paths relative to project root

4. **Size limits**
   - Max file read: 500KB
   - Max test timeout: 300s
   - Directory listing: 200 items max

5. **Validation**
   - All arguments validated before execution
   - Clear error messages returned

---

## Response Format

All tools return JSON in this format:

### Success

```json
{
  "success": true,
  "result": { ... },
  "error": null
}
```

### Error

```json
{
  "success": false,
  "result": null,
  "error": "Error message"
}
```

### Dry Run

```json
{
  "success": true,
  "result": {
    "status": "dry_run",
    "message": "Preview only. Set dry_run=false to apply.",
    ...
  },
  "error": null
}
```

---

## OpenAI Function Calling Format

All tools are compatible with OpenAI function calling:

```json
{
  "type": "function",
  "function": {
    "name": "vetka_search",
    "description": "Search files by name/content",
    "parameters": {
      "type": "object",
      "properties": {
        "query": { "type": "string" },
        "limit": { "type": "integer", "default": 10 }
      },
      "required": ["query"]
    }
  }
}
```

Get all schemas:
```bash
curl http://localhost:5001/api/mcp/tools | jq '.tools'
```

---

## Troubleshooting

### Server not responding

```bash
# Check if server is running
curl http://localhost:5001/api/mcp/status

# Should return:
# {"status": "ok", "tools": 11, ...}
```

### Tool not found

```bash
# List available tools
curl http://localhost:5001/api/mcp/tools | jq '.tools[].function.name'
```

### Permission denied

- Check file path is within project root
- No `..` in path
- File exists (for read operations)

---

## Version

- **Phase:** 22-MCP-2
- **Tools:** 11
- **Tests:** 20 passing
- **Date:** December 2025
